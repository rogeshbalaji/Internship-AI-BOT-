/* Internship Review Automation - dashboard logic (runs fully in the browser) */
const KEY = 'irs_state_v1';
let S = JSON.parse(localStorage.getItem(KEY) || 'null') ||
  { settings: { coord: '', apiKey: '', model: 'claude-sonnet-5-5', total: 4, gap: 7 }, students: [] };
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const uid = () => Math.random().toString(36).slice(2, 10);

function toast(msg, ms = 3500) {
  const t = $('#toast'); t.textContent = msg; t.style.display = 'block';
  clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', ms);
}

/* ---------- Excel parsing helpers ---------- */
function parseDate(v) {
  if (v instanceof Date) { const d = new Date(v.getTime() + 12 * 3600e3); return d.toISOString().slice(0, 10); }
  const s = String(v ?? '').trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/); if (m) return `${m[3]}-${pad(m[2])}-${pad(m[1])}`;
  return today();
}
function parseTime(v) {
  if (v instanceof Date) { const d = new Date(v.getTime() + 12 * 3600e3 * 0); return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; }
  if (typeof v === 'number') { const mins = Math.round(v * 24 * 60); return `${pad(Math.floor(mins / 60) % 24)}:${pad(mins % 60)}`; }
  const s = String(v ?? '').trim(); return s ? s.slice(0, 5) : '10:00';
}

/* ---------- Rendering ---------- */
function badge(st) {
  const cls = { 'Scheduled': 'b-scheduled', 'Reminder Sent': 'b-reminder', 'Submitted': 'b-submitted', 'Completed': 'b-completed' }[st];
  return `<span class="badge ${cls}">${esc(st)}</span>`;
}
function render() {
  const st = S.students, t = today();
  const c = x => st.filter(x).length;
  $('#stats').innerHTML = [
    [st.length, 'Students'], [c(s => s.status === 'Scheduled' && s.date <= t), 'Reviews due'],
    [c(s => s.status === 'Reminder Sent'), 'Awaiting submission'], [c(s => s.status === 'Submitted'), 'Ready for AI review'],
    [c(s => s.status === 'Completed'), 'Completed']
  ].map(([n, l]) => `<div class="stat"><b>${n}</b><span>${l}</span></div>`).join('');

  $('#rows').innerHTML = st.length ? st.map(s => `<tr>
    <td>${esc(s.name)}</td><td>${esc(s.email)}</td><td>#${s.reviewNo}</td><td>${esc(s.date)} ${esc(s.time)}</td>
    <td>${badge(s.status)}</td>
    <td>${s.github ? `<a href="${esc(s.github)}" target="_blank" rel="noopener">GitHub</a>` : ''}${s.recording ? ` · <a href="${esc(s.recording)}" target="_blank" rel="noopener">Recording</a>` : ''}</td>
    <td class="act">
      ${s.status === 'Scheduled' || s.status === 'Reminder Sent' ? `<button data-act="remind" data-id="${s.id}">📧 Reminder</button><button class="alt" data-act="submission" data-id="${s.id}">Add submission</button>` : ''}
      ${s.status === 'Submitted' ? `<button data-act="review" data-id="${s.id}">🤖 AI review</button>` : ''}
      <button class="alt" data-act="history" data-id="${s.id}">History</button>
      <button class="danger" data-act="delete" data-id="${s.id}">✕</button></td></tr>`).join('')
    : '<tr><td colspan="7" class="muted">No students yet. Import an Excel file or add one manually.</td></tr>';
}

/* ---------- Email dialog ---------- */
function showEmail(title, to, subject, body) {
  $('#d-title').textContent = title; $('#d-to').value = to; $('#d-sub').value = subject; $('#d-body').value = body;
  $('#dlg').showModal();
}
$('#d-close').onclick = () => $('#dlg').close();
$('#d-copy').onclick = () => { navigator.clipboard.writeText($('#d-body').value); toast('Message copied'); };
$('#d-mail').onclick = () => {
  location.href = `mailto:${$('#d-to').value}?subject=${encodeURIComponent($('#d-sub').value)}&body=${encodeURIComponent($('#d-body').value)}`;
};

function submitLink(s) {
  const base = location.href.replace(/dashboard\.html.*$/, '');
  const p = new URLSearchParams({ name: s.name, review: s.reviewNo, date: s.date, time: s.time, to: S.settings.coord });
  return `${base}submit.html?${p}`;
}

/* ---------- GitHub data ---------- */
async function githubData(url) {
  const m = url.match(/github\.com\/([^\/\s]+)\/([^\/\s#?]+)/);
  if (!m) throw new Error('Invalid GitHub link');
  const base = `https://api.github.com/repos/${m[1]}/${m[2].replace(/\.git$/, '')}`;
  const get = (p, h) => fetch(base + p, { headers: { Accept: 'application/vnd.github+json', ...h } });
  const r = await get('');
  if (!r.ok) throw new Error(`Cannot access repository (HTTP ${r.status}). It may be private or the link is wrong.`);
  const info = await r.json();
  const commits = (await (await get('/commits?per_page=15')).json().catch(() => [])) || [];
  const treeRes = await get('/git/trees/HEAD?recursive=1');
  const files = treeRes.ok ? (await treeRes.json()).tree.filter(t => t.type === 'blob').map(t => t.path) : [];
  const rr = await get('/readme', { Accept: 'application/vnd.github.raw+json' });
  const readme = rr.ok ? await rr.text() : '';
  return { info, commits: Array.isArray(commits) ? commits : [], files, readme };
}
function describeRepo(d) {
  return `Repo: ${d.info.full_name} | language: ${d.info.language} | last push: ${d.info.pushed_at}\n\nRecent commits:\n` +
    d.commits.map(c => `- ${c.commit.author.date.slice(0, 10)}: ${c.commit.message.split('\n')[0]}`).join('\n') +
    `\n\nFiles (first 80):\n${d.files.slice(0, 80).join('\n')}\n\nREADME (first 3000 chars):\n${d.readme.slice(0, 3000) || 'No README found.'}`;
}

/* ---------- Review engines ---------- */
function localReview(name, d) {
  let score = 0; const good = [], fix = [];
  const has = re => d.files.some(f => re.test(f));
  if (d.readme.length > 300) { score += 2; good.push('Clear README with project description.'); } else fix.push('Write a fuller README: project overview, features, setup steps and screenshots.');
  if (d.commits.length >= 5) { score += 2; good.push(`Regular commit history (${d.commits.length} recent commits).`); } else fix.push('Commit more often with meaningful messages to show steady progress.');
  const last = d.commits[0] && new Date(d.commits[0].commit.author.date);
  if (last && (Date.now() - last) / 864e5 <= 14) { score += 2; good.push('Recent activity in the last two weeks.'); } else fix.push('There has been no recent commit; push your latest work before the review.');
  if (has(/(^|\/)(tests?|__tests__)\/|\.test\.|_test\./i)) { score += 1; good.push('Tests are included.'); } else fix.push('Add basic tests for the main features.');
  if (has(/(^|\/)\.gitignore$/)) { score += 1; good.push('.gitignore present.'); } else fix.push('Add a .gitignore so build files and secrets are not committed.');
  if (d.files.length >= 8) { score += 1; good.push(`Project has a real structure (${d.files.length} files).`); } else fix.push('The project looks small; add more features or modules.');
  if (has(/requirements\.txt|package\.json|pom\.xml|pyproject\.toml/)) { score += 1; good.push('Dependencies are declared.'); } else fix.push('Declare dependencies (requirements.txt / package.json).');
  if (has(/(^|\/)\.env$/)) { score = Math.max(0, score - 2); fix.unshift('A .env file is committed. Remove it and rotate any exposed keys immediately.'); }
  return `SUMMARY\nAutomated review of ${name}'s repository (${d.info.full_name}). Based on repository structure, commits and documentation.\n\n` +
    `STRENGTHS\n${good.length ? good.map(x => '- ' + x).join('\n') : '- None identified yet.'}\n\n` +
    `CHANGES REQUIRED\n${fix.length ? fix.map((x, i) => `${i + 1}. ${x}`).join('\n') : '1. Keep up the good work.'}\n\nSCORE\n${score}/10`;
}
async function claudeReview(s, d, prev) {
  const prompt = `You are reviewing an intern's project for a coordinator.
Student: ${s.name}
Review number: ${s.reviewNo} of ${S.settings.total}

Review criteria:
1. Progress since the last review (commit history, new features)
2. Code quality and structure
3. README and documentation
4. Completeness against a typical internship project scope
5. Best practices (tests, error handling, no secrets committed)

Feedback given at the previous review (check whether it was addressed):
${prev || 'None - this is the first review.'}

Student's repository data:
${describeRepo(d)}

Write the feedback as a plain-text email body with these sections: SUMMARY (2-3 lines), STRENGTHS, CHANGES REQUIRED (numbered, specific, actionable), SCORE (out of 10). Be constructive and concise. Only comment on what the data shows; if something cannot be judged from it, say so.`;
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json', 'x-api-key': S.settings.apiKey,
      'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({ model: S.settings.model, max_tokens: 1200, messages: [{ role: 'user', content: prompt }] })
  });
  if (!res.ok) throw new Error(`Claude API error ${res.status}`);
  return (await res.json()).content[0].text;
}

async function reviewStudent(s, btn) {
  btn.disabled = true; btn.textContent = 'Reviewing…';
  try {
    const d = await githubData(s.github);
    const prev = s.history.length ? s.history[s.history.length - 1].feedback : '';
    let feedback, mode = 'built-in checks';
    if (S.settings.apiKey) {
      try { feedback = await claudeReview(s, d, prev); mode = 'Claude'; }
      catch (e) { toast('Claude failed (' + e.message + '). Using built-in checks.'); feedback = localReview(s.name, d); }
    } else feedback = localReview(s.name, d);

    const no = s.reviewNo, final = no >= S.settings.total;
    s.history.push({ no, feedback, mode, created: new Date().toLocaleString(), github: s.github, recording: s.recording });
    let footer;
    if (final) { s.status = 'Completed'; footer = 'This was your final review. Congratulations on completing the internship!'; }
    else {
      s.reviewNo = no + 1; s.date = addDays(today(), S.settings.gap); s.status = 'Scheduled';
      footer = `NEXT REVIEW: #${s.reviewNo} on ${s.date} at ${s.time}\nSubmission link: ${submitLink(s)}`;
    }
    s.github = ''; s.recording = '';
    save(); render();
    showEmail(`Feedback for ${s.name} (${mode})`, s.email, `Internship Review #${no} - Feedback`,
      `Hi ${s.name},\n\n${feedback}\n\n${footer}\n\nRegards,\nInternship Coordinator`);
  } catch (e) { toast('Review failed: ' + e.message, 6000); btn.disabled = false; btn.textContent = '🤖 AI review'; }
}

/* ---------- Events ---------- */
$('#rows').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const s = S.students.find(x => x.id === b.dataset.id); if (!s) return;
  const act = b.dataset.act;
  if (act === 'remind') {
    s.status = 'Reminder Sent'; save(); render();
    showEmail(`Reminder for ${s.name}`, s.email, `Internship Review #${s.reviewNo} - Submission Link`,
      `Hi ${s.name},\n\nYour internship review #${s.reviewNo} is scheduled for ${s.date} at ${s.time}.\n\nPlease submit your GitHub repository link and screen recording link here:\n${submitLink(s)}\n\nRegards,\nInternship Coordinator`);
  } else if (act === 'submission') {
    const gh = prompt('GitHub repository link:'); if (!gh) return;
    if (!/github\.com\/[^\/\s]+\/[^\/\s]+/.test(gh)) return toast('Invalid GitHub link');
    s.github = gh.trim(); s.recording = (prompt('Screen recording link (optional):') || '').trim();
    s.status = 'Submitted'; save(); render();
  } else if (act === 'review') reviewStudent(s, b);
  else if (act === 'history') {
    showEmail(`Review history: ${s.name}`, s.email, '',
      s.history.length ? s.history.map(h => `--- Review #${h.no} (${h.created}, ${h.mode}) ---\nGitHub: ${h.github}\nRecording: ${h.recording}\n\n${h.feedback}`).join('\n\n') : 'No reviews yet.');
  } else if (act === 'delete' && confirm(`Remove ${s.name}?`)) { S.students = S.students.filter(x => x !== s); save(); render(); }
});

function addStudent(name, email, date, time) {
  if (!name || !/@/.test(email)) return false;
  if (S.students.some(s => s.email.toLowerCase() === email.toLowerCase())) return false;
  S.students.push({ id: uid(), name, email, reviewNo: 1, date, time, status: 'Scheduled', github: '', recording: '', history: [] });
  return true;
}
$('#a-add').onclick = () => {
  const ok = addStudent($('#a-name').value.trim(), $('#a-email').value.trim(), $('#a-date').value || today(), $('#a-time').value || '10:00');
  if (ok) { save(); render(); $('#a-name').value = $('#a-email').value = ''; toast('Student added'); } else toast('Enter a name and a new, valid email');
};
$('#import').onclick = async () => {
  const f = $('#file').files[0]; if (!f) return toast('Choose an Excel file first');
  if (typeof XLSX === 'undefined') return toast('Excel library did not load. Check your internet connection.');
  const wb = XLSX.read(await f.arrayBuffer(), { type: 'array', cellDates: true });
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
  let added = 0;
  rows.forEach(r => {
    const k = {}; Object.keys(r).forEach(key => k[key.trim().toLowerCase()] = r[key]);
    if (addStudent(String(k['name'] || '').trim(), String(k['email'] || '').trim(), parseDate(k['review date']), parseTime(k['review time']))) added++;
  });
  save(); render(); toast(`Imported ${added} of ${rows.length} row(s)`);
};
$('#export').onclick = () => {
  if (typeof XLSX === 'undefined') return toast('Excel library did not load.');
  const data = S.students.map(s => ({ Name: s.name, Email: s.email, 'Review No': s.reviewNo, 'Review Date': s.date, 'Review Time': s.time, Status: s.status, 'Last Feedback': s.history.length ? s.history[s.history.length - 1].feedback : '' }));
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data), 'Students');
  XLSX.writeFile(wb, 'internship-reviews.xlsx');
};
$('#s-save').onclick = () => {
  S.settings = { coord: $('#s-coord').value.trim(), apiKey: $('#s-key').value.trim(), model: $('#s-model').value.trim() || 'claude-sonnet-5-5',
    total: +$('#s-total').value || 4, gap: +$('#s-gap').value || 7 };
  save(); toast('Settings saved');
};

/* ---------- Init ---------- */
$('#s-coord').value = S.settings.coord; $('#s-key').value = S.settings.apiKey; $('#s-model').value = S.settings.model;
$('#s-total').value = S.settings.total; $('#s-gap').value = S.settings.gap;
render();
